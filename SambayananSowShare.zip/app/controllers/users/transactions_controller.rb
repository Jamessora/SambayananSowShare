class Users::TransactionsController < ApplicationController
    include UserActions
    
    before_action :authenticate_user!
    before_action :check_kyc_status
    before_action :set_user
    
    def create
      Rails.logger.debug "Creating a new transaction"
      
      crop = Crop.find_by(id: params[:crop_id])
      if crop.nil?
        render json: { status: 'error', message: 'Crop not found' } and return
      end
  
      @transaction = Transaction.new(
        buyer_id: current_user.id, 
        seller_id: crop.user_id,
        status: 'Pending'
      )
      
      if @transaction.save
        Rails.logger.debug "Transaction created successfully"
        render json: { status: 'success', transaction: @transaction }
      else
        Rails.logger.error "Error creating transaction: #{@transaction.errors.full_messages.join(", ")}"
        render json: { status: 'error', message: @transaction.errors.full_messages }
      end
    end
  
    def update
      Rails.logger.debug "Updating transaction"
      
      @transaction = Transaction.find_by(id: params[:id])
      Rails.logger.debug "Fetched Transaction: #{@transaction.inspect}"
      if @transaction.nil?
        render json: { status: 'error', message: 'Transaction not found' } and return
      end
    
      new_status = params[:status]
      Rails.logger.debug "New Status: #{new_status}"
      
     
      allowed_statuses = case current_user
      when @transaction.buyer
        ['For Seller Confirmation', 'Payment Sent For Seller Confirmation', 'Completed']
      when @transaction.seller
        ['For Buyer Payment', 'For Delivery']
      else
        []
      end
      Rails.logger.debug "Allowed Statuses: #{allowed_statuses.inspect}"
      
      

      if allowed_statuses.include?(new_status)
        # Update the total_price only when the status is 'For Seller Confirmation'
        if new_status == 'For Seller Confirmation'
          total_price = @transaction.transaction_crops.sum(:price)
          Rails.logger.debug "Inside For Seller Confirmation block. Starting price calculation."

          if @transaction.update(status: new_status, total_price: total_price)
            Rails.logger.debug "Transaction updated successfully inside seller confirmation"
          else
            Rails.logger.debug "Transaction update failed: #{@transaction.errors.full_messages.join(", ")}"
          end
        else
          @transaction.update(status: new_status)
          Rails.logger.debug "Transaction updated successfully not inside seller confirmation"
        end
      else
        render json: { status: 'error', message: 'Invalid status' }
      end
    end
  end
  