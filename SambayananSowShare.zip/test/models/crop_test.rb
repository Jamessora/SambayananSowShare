require "test_helper"

class CropTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
