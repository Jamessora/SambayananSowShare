require "test_helper"

class AdminMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
