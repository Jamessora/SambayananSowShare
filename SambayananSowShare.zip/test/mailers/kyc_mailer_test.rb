require "test_helper"

class KycMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
