# Preview all emails at http://localhost:3000/rails/mailers/kyc_mailer
class KycMailerPreview < ActionMailer::Preview

end
